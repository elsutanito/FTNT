#!/usr/bin/env python3

import csv, io, yaml, subprocess
from paramiko import SSHClient, AutoAddPolicy, ssh_exception
from contextlib import redirect_stdout
from paramiko_expect import SSHClientInteraction
import requests
from pathlib import Path

requests.packages.urllib3.disable_warnings()

#Get info from YAML
inventory_path = Path(__file__).resolve().parent / "inventory.yaml"
with inventory_path.open("r") as f:
    inv = yaml.safe_load(f)

fmg_user = inv.get("fmg_user", "admin")
fmg_password = inv.get("fmg_password", "Fortinet123#")
fmg_ip = str(inv.get("fmg_ip", "10.254.1.2"))
fmg_sessionToken = ""
fmg_adom = inv.get("fmg_adom", "XPerts25")
fgt_user = inv.get("fgt_user", "admin")
fgt_password = inv.get("fgt_password", "Fortinet123#")
csv_file_path = "/fabric/4d-sase-amer-intl/fgt_inventory.csv"

FGTs = ["site1-1", "site1-2","site1-H1","site1-H2","site2-1","site2-H1"]

# ------- FMG
def fmg_login():
    url = f"https://{fmg_ip}/jsonrpc"
    payload = {
        "id": 1,
        "method": "exec",
        "params": [
            {
                "data": {"passwd": fmg_password, "user": fmg_user},
                "url": "/sys/login/user",
            }
        ],
    }
    response = requests.post(url, json=payload, verify=False).json()
    if "session" in response:
        fmg_sessionToken = response["session"]
        return fmg_sessionToken
    else:
        print("FMG login error")
        exit()


def fmg_deleteSn(fmg_sessionToken, fgt_sn):
    url = f"https://{fmg_ip}/jsonrpc"
    payload = {
        "method": "exec",
        "params": [
            {
                "data": {"adom": [fmg_adom], "device": [fgt_sn]},
                "url": "/dvm/cmd/del/device",
            }
        ],
        "session": fmg_sessionToken,
        "id": 1,
    }
    response = requests.post(url, json=payload, verify=False).json()
    #print(response)


def fmg_replaceFGTsn(fmg_sessionToken, fgt_name, fgt_sn):
    url = f"https://{fmg_ip}/jsonrpc"
    payload = {
        "method": "exec",
        "params": [
            {
                "data": {"sn": fgt_sn},
                "url": "/dvmdb/device/replace/sn/" + fgt_name
            }
        ],
        "session": fmg_sessionToken,
        "id": 1,
    }
    response = requests.post(url, json=payload, verify=False).json()
    #print(response)


def fmg_getSnByName(fmg_sessionToken, fgt_name):
    url = f"https://{fmg_ip}/jsonrpc"
    payload = {
        "method": "get",
        "params": [
            {
                "expand member": "string",
                "fields": "sn",
                "filter": [["name", "==", fgt_name]],
                "loadsub": 0,
                "range": [[2, 5]],
                "url": "/dvmdb/device",
            }
        ],
        "session": fmg_sessionToken,
        "id": 1,
    }
    response = requests.post(url, json=payload, verify=False).json()
    if len(response["result"][0]["data"]) > 0:
        return response["result"][0]["data"][0]["sn"]
    else:
        return ""


# --------- FGT
def fgt_getSN(fortigate_name):
    with open(csv_file_path, mode='r', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if len(row) < 3:
                continue  # Skip rows with insufficient columns
            serial_number = row[0]
            name = row[2]
            if name.strip().lower() == fortigate_name.strip().lower():
                return serial_number

# ------- MAIN
def main():
    print()
    print("Generating FortiGate inventory")
    subprocess.run(["/fabric/4d-sase-amer-intl/generate_inventory.sh"])
    print()
    print("Starting to fix FGTs SNs on FMG")
    print("=======================")
    fmg_sessionToken = fmg_login()

    for fgt_name in FGTs:
        fgt_sn = fgt_getSN(fgt_name)
        print(f"{fgt_name} FGT SN:    {fgt_sn}")
        fmgFgtSn = fmg_getSnByName(fmg_sessionToken, fgt_name)
        print(f"{fgt_name} SN on FMG: {fmgFgtSn}")

        fmg_deleteSn(fmg_sessionToken, fgt_sn)
        if not fmgFgtSn == "" and not fgt_sn in fmgFgtSn:
            fmg_deleteSn(fmg_sessionToken, fgt_sn)
            fmg_replaceFGTsn(fmg_sessionToken, fgt_name, fgt_sn)
            print(f"{fgt_name} SN fixed")
        else:
            print(f"{fgt_name} Nothing to apply")

if __name__ == "__main__":
    main()
